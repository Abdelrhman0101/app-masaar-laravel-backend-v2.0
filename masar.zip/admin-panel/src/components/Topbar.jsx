export default function Topbar() {
  return (
    <header className="h-16 bg-white shadow flex items-center px-6 justify-between">
      <span className="font-bold text-lg">نظام الإدارة</span>
      {/* هنا ممكن تضيف بيانات الأدمن، زر تسجيل خروج، إلخ */}
    </header>
  );
}
