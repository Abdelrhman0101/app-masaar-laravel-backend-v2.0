export default function DashboardHome() {
  return (
    <div>
      <h1>لوحة التحكم</h1>
      <p>مرحبًا بك في لوحة تحكم الإدارة.</p>
    </div>
  );
}
