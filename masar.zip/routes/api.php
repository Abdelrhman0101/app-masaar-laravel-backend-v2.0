<?php

use App\Http\Controllers\AdminServiceRequestController;
use App\Http\Controllers\CarRentalOfficesDetailController;
use App\Http\Controllers\ProviderServiceRequestController;
use App\Http\Controllers\Auth\RegisteredUserController;
use App\Http\Controllers\UploadController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PropertyController;
use App\Http\Controllers\AppointmentController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\SecurityPermitController;
use App\Http\Controllers\RestaurantController;
use App\Http\Controllers\MenuSectionController;
use App\Http\Controllers\MenuItemController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\CarController;
use App\Http\Controllers\CarServiceOrderController;
use App\Http\Controllers\OfferController;
use App\Http\Controllers\ServiceRequestController;
use App\Http\Controllers\AppSettingController;
use App\Http\Controllers\Api\UserChatController;
use App\Http\Controllers\Api\AdminChatController;
use App\Http\Controllers\Api\RestaurantProfileController;
use App\Http\Controllers\ConversationController;
use App\Http\Controllers\MessageController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Broadcast;
use App\Http\Controllers\Api\RestaurantBannerController;
use App\Http\Controllers\Api\PublicRestaurantController;
use App\Http\Controllers\Api\PublicPropertyController;
use App\Http\Controllers\Api\MyOrdersController; // <-- أضف هذا


Broadcast::routes(['middleware' => ['auth:sanctum']]);

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

// Public Routes
Route::post('/register', [RegisteredUserController::class, 'store']);
Route::post('/login', [LoginController::class, 'login']);
Route::post('/upload', [UploadController::class, 'upload']);
Route::get('/settings', [AppSettingController::class, 'index']);

// Authenticated Routes
Route::middleware('auth:sanctum')->group(function () {
    // User Profile
    Route::get('/user', function (Request $request) {
        $user = $request->user();
        $user->loadMissing([
            'normalUser', 'realEstate.officeDetail', 'realEstate.individualDetail',
            'restaurantDetail', 'carRental.officeDetail', 'carRental.driverDetail'
        ]);
        return response()->json($user);
    });

    // Users
    Route::get('/users', [UserController::class, 'index']);
    Route::post('/users', [UserController::class, 'store']);
    Route::put('/users/{id}', [UserController::class, 'update']);
    Route::delete('/users/{id}', [UserController::class, 'destroy']);

    // Properties
    Route::get('/properties', [PropertyController::class, 'index']);
    Route::post('/properties', [PropertyController::class, 'store']);
    Route::put('/properties/{id}', [PropertyController::class, 'update']);
    Route::delete('/properties/{id}', [PropertyController::class, 'destroy']);
    Route::get('/all-properties', [PropertyController::class, 'allProperties']);

    // Appointments
    Route::get('/appointments', [AppointmentController::class, 'index']);
    Route::post('/appointments', [AppointmentController::class, 'store']);
    Route::put('/appointments/{id}/status', [AppointmentController::class, 'updateStatus']);
    Route::get('/my-appointments', [AppointmentController::class, 'myAppointments']);
    Route::get('/provider-appointments', [AppointmentController::class, 'providerAppointments']);

    // Notifications
    Route::get('/notifications', [NotificationController::class, 'index']);
    Route::put('/notifications/{id}/read', [NotificationController::class, 'markAsRead']);
    Route::delete('/notifications/{id}', [NotificationController::class, 'destroy']);

    // Security Permits
    Route::post('/security-permits', [SecurityPermitController::class, 'store']);
    Route::get('/my-security-permits', [SecurityPermitController::class, 'myPermits']);
    Route::get('/all-security-permits', [SecurityPermitController::class, 'allPermits']);

    // Restaurant Orders
    Route::post('/orders', [OrderController::class, 'store']);
    Route::get('/restaurant/orders', [OrderController::class, 'restaurantOrders']);
    Route::post('/restaurant/orders/{order}/process', [OrderController::class, 'process']);
    Route::post('/restaurant/orders/{order}/complete', [OrderController::class, 'complete']);

    // Restaurant Profile
    Route::prefix('restaurant')->group(function () {
        Route::get('/details', [RestaurantProfileController::class, 'show']);
        Route::post('/details/update', [RestaurantProfileController::class, 'update']);
    });

    // Cars
    Route::get('/car-rentals/{carRentalId}/cars', [CarController::class, 'index']);
    Route::post('/cars', [CarController::class, 'store']);
    Route::put('/cars/{id}', [CarController::class, 'update']);
    Route::delete('/cars/{id}', [CarController::class, 'destroy']);
    Route::get('/cars/{id}', [CarController::class, 'show']);

    // Car Service Orders
    Route::post('/car-orders', [CarServiceOrderController::class, 'store']);
    Route::get('/car-orders', [CarServiceOrderController::class, 'index']);
    Route::get('/car-orders/{id}', [CarServiceOrderController::class, 'show']);
    Route::post('/car-orders/{id}/offer', [CarServiceOrderController::class, 'offer']);
    Route::post('/car-orders/{order_id}/offer/{offer_id}/accept', [CarServiceOrderController::class, 'acceptOffer']);
    Route::patch('/car-rental-office-detail/{id}/availability', [CarRentalOfficesDetailController::class, 'updateAvailability']);

    // Service Requests
    Route::post('/service-requests', [ServiceRequestController::class, 'store']);
    Route::get('/service-requests', [ServiceRequestController::class, 'index']);
    Route::post('/offers', [OfferController::class, 'store']);

    // Provider Service Requests
    Route::get('/provider/service-requests', [ProviderServiceRequestController::class, 'index']);
    Route::post('/provider/service-requests/{id}/accept', [ProviderServiceRequestController::class, 'accept']);
    Route::get('/provider/service-requests/accept', [ProviderServiceRequestController::class, 'acceptedRequests']);
    Route::post('/provider/service-requests/{id}/complete', [ProviderServiceRequestController::class, 'complete']);
    Route::get('/provider/service-requests/complete', [ProviderServiceRequestController::class, 'completedRequests']);

    // Conversations and Messages
    Route::get('/conversations', [ConversationController::class, 'index']);
    Route::post('/conversations/start', [ConversationController::class, 'startOrGet']);
    Route::get('/conversations/{id}/messages', [MessageController::class, 'index']);
    Route::post('/messages', [MessageController::class, 'store']);
    Route::delete('/messages/{id}', [MessageController::class, 'destroy']);
    Route::get('/chat', [UserChatController::class, 'show']);
    Route::post('/chat', [UserChatController::class, 'store']);

    // Settings
    Route::put('/settings/{key}', [AppSettingController::class, 'update']);
});

// Admin Routes
Route::middleware(['auth:sanctum'])->group(function () {
    Route::get('/security-permits', [SecurityPermitController::class, 'index']);
    Route::put('/security-permits/{id}/status', [SecurityPermitController::class, 'updateStatus']);
    Route::put('/restaurants/{id}/the-best', [RestaurantController::class, 'updateTheBest']);
    Route::put('/properties/{id}/the-best', [PropertyController::class, 'updateTheBest']);
    Route::get('/orders', [OrderController::class, 'index']);
    Route::get('/orders/{order}', [OrderController::class, 'show']);
    Route::post('/orders/{order}/approve', [OrderController::class, 'approve']);
    Route::post('/orders/{order}/reject', [OrderController::class, 'reject']);
    Route::post('/car-orders/{id}/admin-approve', [CarServiceOrderController::class, 'approveByAdmin']);
    Route::post('/car-orders/{id}/admin-reject', [CarServiceOrderController::class, 'rejectByAdmin']);
    Route::get('/admin/service-requests/all', [AdminServiceRequestController::class, 'archive']);
    Route::get('/admin/chats', [AdminChatController::class, 'index'])->name('api.admin.chats.index');
});
Route::middleware(['auth:sanctum'])->prefix('admin')->group(function () {
    Route::get('/service-requests', [\App\Http\Controllers\Admin\ServiceRequestAdminController::class, 'index']);
    Route::post('/service-requests/{id}/approve', [\App\Http\Controllers\Admin\ServiceRequestAdminController::class, 'approve']);
    Route::post('/service-requests/{id}/reject', [\App\Http\Controllers\Admin\ServiceRequestAdminController::class, 'reject']);
});
// Menu Sections and Items (Public)
Route::post('/menu-sections', [MenuSectionController::class, 'store']);
Route::put('/menu-sections/{id}', [MenuSectionController::class, 'update']);
Route::delete('/menu-sections/{id}', [MenuSectionController::class, 'destroy']);
Route::get('/restaurants/{restaurantId}/menu-sections', [MenuSectionController::class, 'index']);

Route::post('/menu-items', [MenuItemController::class, 'store']);
Route::put('/menu-items/{id}', [MenuItemController::class, 'update']);
Route::delete('/menu-items/{id}', [MenuItemController::class, 'destroy']);
Route::get('/menu-sections/{sectionId}/items', [MenuItemController::class, 'index']);

// مسار لجلب قائمة البنرات (متاح للجميع)
Route::get('/restaurant-banners', [RestaurantBannerController::class, 'index']);
Route::post('/restaurant-banners', [RestaurantBannerController::class, 'store']);
Route::delete('/restaurant-banners/{banner}', [RestaurantBannerController::class, 'destroy']);


Route::get('/public-restaurants', [PublicRestaurantController::class, 'index']);

// Endpoint رقم 2: جلب التفاصيل الكاملة لمطعم واحد باستخدام الـ ID الخاص به
// لاحظ أن اسم {user} يطابق المتغير في دالة الكنترولر (Route Model Binding)
Route::get('/public-restaurants/{user}', [PublicRestaurantController::class, 'show']);


Route::get('/public-restaurants', [PublicRestaurantController::class, 'index']);
Route::get('/public-restaurants/{user}', [PublicRestaurantController::class, 'show']);
Route::get('/public-menu-sections', [\App\Http\Controllers\Api\PublicRestaurantController::class, 'getMenuSections']);

// !! المسار الجديد الخاص بالعقارات !!
Route::get('/public-properties', [PublicPropertyController::class, 'index']);


Route::middleware('auth:sanctum')->group(function () {
    Route::get('/my-orders/all', [MyOrdersController::class, 'getAllMyOrders']);
});