@extends('layouts.dashboard')

@section('title', 'التحكم في التطبيق')

@section('content')
<style>
/* Modern App Controller Styles */
.modern-app-title {
    background: linear-gradient(135deg, #ff6b35, #f7931e);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    font-weight: 800;
    font-size: 2.5rem;
    text-shadow: 2px 2px 4px rgba(255, 107, 53, 0.3);
    margin-bottom: 2rem;
    position: relative;
}

.modern-app-title::after {
    content: '';
    position: absolute;
    bottom: -10px;
    left: 0;
    width: 100px;
    height: 4px;
    background: linear-gradient(90deg, #ff6b35, #f7931e);
    border-radius: 2px;
    box-shadow: 0 2px 8px rgba(255, 107, 53, 0.4);
}

/* Modern Tabs */
.modern-tabs {
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 8px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    margin-bottom: 2rem;
}

.modern-tab-button {
    background: transparent;
    border: none;
    padding: 12px 24px;
    border-radius: 10px;
    color: #666;
    font-weight: 600;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
}

.modern-tab-button:hover {
    background: rgba(255, 107, 53, 0.1);
    color: #ff6b35;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(255, 107, 53, 0.2);
}

.modern-tab-button.active {
    background: linear-gradient(135deg, #ff6b35, #f7931e);
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(255, 107, 53, 0.4);
}

.modern-tab-button.active::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
    animation: shimmer 2s infinite;
}

/* Modern Cards Container */
.modern-cards-container {
    padding: 20px;
    background: linear-gradient(135deg, rgba(255, 107, 53, 0.05), rgba(247, 147, 30, 0.05));
    border-radius: 20px;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
}

/* Modern Cards */
.modern-card {
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(15px);
    border-radius: 20px;
    border: 1px solid rgba(255, 255, 255, 0.3);
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    overflow: hidden;
    position: relative;
    height: 100%;
}

.modern-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #ff6b35, #f7931e, #ff6b35);
    background-size: 200% 100%;
    animation: gradientShift 3s ease-in-out infinite;
}

.modern-card:hover {
    transform: translateY(-10px) scale(1.02);
    box-shadow: 0 25px 50px rgba(255, 107, 53, 0.2);
    border-color: rgba(255, 107, 53, 0.3);
}

.modern-card-header {
    padding: 20px 20px 15px;
    background: linear-gradient(135deg, rgba(255, 107, 53, 0.1), rgba(247, 147, 30, 0.1));
    border-bottom: 1px solid rgba(255, 107, 53, 0.2);
    position: relative;
}

.modern-card-header::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 20px;
    right: 20px;
    height: 2px;
    background: linear-gradient(90deg, #ff6b35, #f7931e);
    border-radius: 1px;
}

.modern-card-body {
    padding: 20px;
}

/* Logo/Image Styles */
.modern-logo {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid rgba(255, 107, 53, 0.3);
    box-shadow: 0 4px 12px rgba(255, 107, 53, 0.2);
    transition: all 0.3s ease;
    cursor: pointer;
}

.modern-logo:hover {
    transform: scale(1.1) rotate(5deg);
    border-color: #ff6b35;
    box-shadow: 0 6px 20px rgba(255, 107, 53, 0.4);
}

.modern-property-image {
    width: 100%;
    height: 120px;
    border-radius: 12px;
    object-fit: cover;
    border: 2px solid rgba(255, 107, 53, 0.2);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease;
    cursor: pointer;
    margin-bottom: 15px;
}

.modern-property-image:hover {
    transform: scale(1.05);
    border-color: #ff6b35;
    box-shadow: 0 8px 25px rgba(255, 107, 53, 0.3);
}

/* Info Section */
.modern-info-section {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 15px;
}

.modern-info-text {
    flex: 1;
}

.modern-title {
    font-size: 1.3rem;
    font-weight: 700;
    color: #333;
    margin-bottom: 5px;
    background: linear-gradient(135deg, #ff6b35, #f7931e);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.modern-subtitle {
    color: #666;
    font-size: 0.9rem;
    font-weight: 500;
}

/* Details Section */
.modern-details {
    margin: 15px 0;
}

.modern-detail-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 0;
    border-bottom: 1px solid rgba(255, 107, 53, 0.1);
    transition: all 0.3s ease;
}

.modern-detail-item:hover {
    background: rgba(255, 107, 53, 0.05);
    padding-left: 10px;
    border-radius: 8px;
}

.modern-detail-icon {
    width: 20px;
    height: 20px;
    background: linear-gradient(135deg, #ff6b35, #f7931e);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 10px;
    box-shadow: 0 2px 6px rgba(255, 107, 53, 0.3);
}

.modern-detail-label {
    font-weight: 600;
    color: #333;
    min-width: 80px;
}

.modern-detail-value {
    color: #666;
    flex: 1;
}

/* Action Section */
.modern-actions {
    padding-top: 15px;
    border-top: 2px solid rgba(255, 107, 53, 0.1);
    margin-top: 15px;
}

.modern-favorite-btn {
    background: linear-gradient(135deg, #ff6b35, #f7931e);
    border: none;
    color: white;
    padding: 10px 20px;
    border-radius: 25px;
    font-weight: 600;
    font-size: 0.9rem;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
    box-shadow: 0 4px 15px rgba(255, 107, 53, 0.3);
    width: 100%;
}

.modern-favorite-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(255, 107, 53, 0.4);
}

.modern-favorite-btn.active {
    background: linear-gradient(135deg, #28a745, #20c997);
    box-shadow: 0 4px 15px rgba(40, 167, 69, 0.3);
}

.modern-favorite-btn.active:hover {
    box-shadow: 0 8px 25px rgba(40, 167, 69, 0.4);
}

.modern-favorite-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
    transition: left 0.5s;
}

.modern-favorite-btn:hover::before {
    left: 100%;
}

/* Animations */
@keyframes gradientShift {
    0%, 100% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
}

@keyframes shimmer {
    0% { left: -100%; }
    100% { left: 100%; }
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.modern-card.new-card-animation {
    animation: fadeInUp 0.6s ease-out;
}

/* Responsive Design */
@media (max-width: 768px) {
    .modern-app-title {
        font-size: 2rem;
    }
    
    .modern-card-header,
    .modern-card-body {
        padding: 15px;
    }
    
    .modern-logo {
        width: 50px;
        height: 50px;
    }
    
    .modern-property-image {
        height: 100px;
    }
    
    .modern-title {
        font-size: 1.1rem;
    }
}

@media (max-width: 480px) {
    .modern-app-title {
        font-size: 1.8rem;
    }
    
    .modern-tab-button {
        padding: 10px 16px;
        font-size: 0.9rem;
    }
    
    .modern-card-header,
    .modern-card-body {
        padding: 12px;
    }
    
    .modern-logo {
        width: 45px;
        height: 45px;
    }
    
    .modern-property-image {
        height: 80px;
    }
}
</style>

<h2 class="modern-app-title">التحكم في التطبيق</h2>
<div class="modern-tabs">
    <div class="d-flex gap-2" id="controlTabs">
        <button class="modern-tab-button active" id="tab-restaurants" onclick="switchTab('restaurants')">المطاعم</button>
        <button class="modern-tab-button" id="tab-properties" onclick="switchTab('properties')">العقارات</button>
    </div>
</div>
<div id="controlTabContent" class="mt-4"></div>

<!-- Modal لعرض الصورة -->
<div class="modal fade" id="imgModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <img id="imgModalSrc" src="" style="max-width:98vw;max-height:85vh;display:block;margin:auto;">
    </div>
</div>
@endsection

@section('scripts')
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const baseUrl = 'http://192.168.1.7:8000'; // عدل حسب السيرفر

let currentTab = 'restaurants';
let restaurants = [];
let properties = [];
let pollingInterval = null;

console.log('[CONTROL] Script loaded.');

// Tabs logic
function switchTab(tab) {
    document.querySelectorAll('#controlTabs button').forEach(btn => btn.classList.remove('active'));
    document.getElementById(`tab-${tab}`).classList.add('active');
    
    currentTab = tab;
    // عند تغيير التبويب، يتم إفراغ المحتوى والبدء من جديد
    document.getElementById('controlTabContent').innerHTML = ''; 
    renderCurrentTab();
}

function renderCurrentTab(auto = false) {
    if (currentTab === 'restaurants') {
        fetchRestaurants(auto);
    } else if (currentTab === 'properties') {
        fetchProperties(auto);
    }
}

// -------------------- المطاعم --------------------
async function fetchRestaurants(auto = false) {
    const token = localStorage.getItem('token');
    // إظهار الدوّار فقط عند التحميل الأول
    if (!auto && !document.getElementById('restaurants-container')) {
        document.getElementById('controlTabContent').innerHTML = `<div class="text-center py-5"><div class="spinner-border"></div></div>`;
    }
    try {
        const res = await fetch(`${baseUrl}/api/users`, {
            headers: { 'Authorization': 'Bearer ' + token, 'Accept': 'application/json' }
        });
        const data = await res.json();
        restaurants = (Array.isArray(data.users) ? data.users : []).filter(u => u.user_type === 'restaurant');
        if (!auto) console.log('[CONTROL] Restaurants loaded:', restaurants.length);
        renderRestaurants(!auto); // إرسال علامة للتمييز بين التحميل الأول والتحديث
    } catch (e) {
        if (!auto) {
            console.error('[CONTROL] Error loading restaurants:', e);
            document.getElementById('controlTabContent').innerHTML = `<div class="alert alert-danger">تعذر تحميل المطاعم!</div>`;
        }
    }
}

function renderRestaurants(isFirstRender = false) {
    const container = document.getElementById('controlTabContent');
    
    // إذا كان أول تحميل، قم بإنشاء الحاوية الرئيسية
    if (isFirstRender) {
        if (!restaurants.length) {
            container.innerHTML = `<div class="alert alert-warning">لا توجد مطاعم حالياً.</div>`;
            return;
        }
        let initialHtml = `<div class="modern-cards-container"><div class="row g-4" id="restaurants-container"></div></div>`;
        container.innerHTML = initialHtml;
    }
    
    const cardsContainer = document.getElementById('restaurants-container');
    if (!cardsContainer) return;

    const existingCardIds = new Set([...cardsContainer.children].map(c => c.id));
    const incomingCardIds = new Set(restaurants.map(r => `restaurant-card-${r.id}`));

    // تحديث وإضافة الكروت
    restaurants.forEach(r => {
        const cardId = `restaurant-card-${r.id}`;
        const isBest = r.the_best == 1;
        
        let existingCard = document.getElementById(cardId);
        
        if (existingCard) { // الكارت موجود، قم بتحديثه فقط
            const favButton = existingCard.querySelector('.modern-favorite-btn');
            const currentIsBest = favButton.classList.contains('active');

            if (isBest !== currentIsBest) {
                favButton.className = `modern-favorite-btn ${isBest ? 'active' : ''}`;
                favButton.innerHTML = `<i class="fas fa-star"></i> ${isBest ? 'مُفضّل' : 'إضافة للمفضلة'}`;
                favButton.onclick = (event) => toggleRestaurantBest(event, r.id, isBest ? 0 : 1);
            }
        } else { // الكارت غير موجود، قم بإنشائه وإضافته
            let logo = r.restaurant_detail?.logo_image || r.restaurant_detail?.profile_image || '';
            const cardHtml = `
                <div class="modern-card new-card-animation">
                    <div class="modern-card-header">
                        <div class="modern-info-section">
                            ${logo ? `<img src="${logo}" class="modern-logo" onclick="openImgFull('${logo}')">` : ''}
                            <div class="modern-info-text">
                                <div class="modern-title">${r.restaurant_detail?.restaurant_name || r.name}</div>
                                <div class="modern-subtitle">${r.email}</div>
                            </div>
                        </div>
                    </div>
                    <div class="modern-card-body">
                        <div class="modern-details">
                            <div class="modern-detail-item">
                                <div class="modern-detail-icon">📍</div>
                                <div class="modern-detail-label">المحافظة:</div>
                                <div class="modern-detail-value">${r.governorate ?? '-'}</div>
                            </div>
                            <div class="modern-detail-item">
                                <div class="modern-detail-icon">📞</div>
                                <div class="modern-detail-label">الهاتف:</div>
                                <div class="modern-detail-value">${r.phone ?? '-'}</div>
                            </div>
                        </div>
                        <div class="modern-actions">
                            <button type="button"
                                class="modern-favorite-btn ${isBest ? 'active' : ''}"
                                onclick="toggleRestaurantBest(event, ${r.id}, ${isBest ? 0 : 1})">
                                <i class="fas fa-star"></i> ${isBest ? 'مُفضّل' : 'إضافة للمفضلة'}
                            </button>
                        </div>
                    </div>
                </div>`;
            const colDiv = document.createElement('div');
            colDiv.className = 'col-md-6 col-lg-4';
            colDiv.id = cardId;
            colDiv.innerHTML = cardHtml;
            cardsContainer.appendChild(colDiv);
        }
    });

    // إزالة الكروت التي لم تعد موجودة
    existingCardIds.forEach(cardId => {
        if (!incomingCardIds.has(cardId)) {
            const cardToRemove = document.getElementById(cardId);
            if(cardToRemove) cardToRemove.remove();
        }
    });
}

async function toggleRestaurantBest(event, id, val) {
    event.preventDefault();
    console.log(`[CONTROL] Toggle restaurant #${id} to the_best=${val}`);
    const token = localStorage.getItem('token');
    try {
        const res = await fetch(`${baseUrl}/api/users/${id}`, {
            method: 'PUT',
            headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify({ the_best: val })
        });
        if (res.ok) {
            console.log(`[CONTROL] Restaurant #${id} updated successfully.`);
            fetchRestaurants(true); // تحديث البيانات في الخلفية
        } else {
            const text = await res.text();
            console.error(`[CONTROL] Error updating restaurant #${id}:`, text);
            alert('خطأ أثناء تغيير حالة المفضل!');
        }
    } catch (e) {
        console.error(`[CONTROL] Exception updating restaurant #${id}:`, e);
        alert('خطأ أثناء تغيير حالة المفضل!');
    }
}

// -------------------- العقارات --------------------
async function fetchProperties(auto = false) {
    const token = localStorage.getItem('token');
    if (!auto && !document.getElementById('properties-container')) {
        document.getElementById('controlTabContent').innerHTML = `<div class="text-center py-5"><div class="spinner-border"></div></div>`;
    }
    try {
        const res = await fetch(`${baseUrl}/api/all-properties`, {
            headers: { 'Authorization': 'Bearer ' + token, 'Accept': 'application/json' }
        });
        const data = await res.json();
        properties = Array.isArray(data) ? data : (data.properties ?? []);
        if (!auto) console.log('[CONTROL] Properties loaded:', properties.length);
        renderProperties(!auto);
    } catch (e) {
        if (!auto) {
            console.error('[CONTROL] Error loading properties:', e);
            document.getElementById('controlTabContent').innerHTML = `<div class="alert alert-danger">تعذر تحميل العقارات!</div>`;
        }
    }
}

function renderProperties(isFirstRender = false) {
    const container = document.getElementById('controlTabContent');
    
    if (isFirstRender) {
        if (!properties.length) {
            container.innerHTML = `<div class="alert alert-warning">لا توجد عقارات حالياً.</div>`;
            return;
        }
        let initialHtml = `<div class="modern-cards-container"><div class="row g-4" id="properties-container"></div></div>`;
        container.innerHTML = initialHtml;
    }
    
    const cardsContainer = document.getElementById('properties-container');
    if (!cardsContainer) return;
    
    const existingCardIds = new Set([...cardsContainer.children].map(c => c.id));
    const incomingCardIds = new Set(properties.map(p => `property-card-${p.id}`));

    properties.forEach(p => {
        const cardId = `property-card-${p.id}`;
        const isBest = p.the_best == 1;
        
        let existingCard = document.getElementById(cardId);
        
        if (existingCard) {
            const favButton = existingCard.querySelector('.modern-favorite-btn');
            const currentIsBest = favButton.classList.contains('active');

            if (isBest !== currentIsBest) {
                favButton.className = `modern-favorite-btn ${isBest ? 'active' : ''}`;
                favButton.innerHTML = `<i class="fas fa-star"></i> ${isBest ? 'مُفضّل' : 'إضافة للمفضلة'}`;
                favButton.onclick = (event) => togglePropertyBest(event, p.id, isBest ? 0 : 1);
            }
        } else {
            const cardHtml = `
                <div class="modern-card new-card-animation">
                     <div class="modern-card-header">
                        ${p.image_url ? `<img src="${p.image_url}" class="modern-property-image" onclick="openImgFull('${p.image_url}')">` : ''}
                        <div class="modern-info-text">
                            <div class="modern-title">${p.type ?? 'عقار'}</div>
                            <div class="modern-subtitle">${p.address}</div>
                        </div>
                    </div>
                    <div class="modern-card-body">
                        <div class="modern-details">
                            <div class="modern-detail-item">
                                <div class="modern-detail-icon">💰</div>
                                <div class="modern-detail-label">السعر:</div>
                                <div class="modern-detail-value">${p.price} جنيه</div>
                            </div>
                            <div class="modern-detail-item">
                                <div class="modern-detail-icon">📐</div>
                                <div class="modern-detail-label">المساحة:</div>
                                <div class="modern-detail-value">${p.area ?? '-'}</div>
                            </div>
                        </div>
                        <div class="modern-actions">
                            <button type="button"
                                class="modern-favorite-btn ${isBest ? 'active' : ''}"
                                onclick="togglePropertyBest(event, ${p.id}, ${isBest ? 0 : 1})">
                                <i class="fas fa-star"></i> ${isBest ? 'مُفضّل' : 'إضافة للمفضلة'}
                            </button>
                        </div>
                    </div>
                </div>`;
            const colDiv = document.createElement('div');
            colDiv.className = 'col-md-6 col-lg-4';
            colDiv.id = cardId;
            colDiv.innerHTML = cardHtml;
            cardsContainer.appendChild(colDiv);
        }
    });

    existingCardIds.forEach(cardId => {
        if (!incomingCardIds.has(cardId)) {
            const cardToRemove = document.getElementById(cardId);
            if (cardToRemove) cardToRemove.remove();
        }
    });
}


async function togglePropertyBest(event, id, val) {
    event.preventDefault();
    console.log(`[CONTROL] Toggle property #${id} to the_best=${val}`);
    const token = localStorage.getItem('token');
    try {
        const res = await fetch(`${baseUrl}/api/properties/${id}`, {
            method: 'PUT',
            headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json', 'Accept': 'application/json' },
            body: JSON.stringify({ the_best: val })
        });
        if (res.ok) {
            console.log(`[CONTROL] Property #${id} updated successfully.`);
            fetchProperties(true);
        } else {
            const text = await res.text();
            console.error(`[CONTROL] Error updating property #${id}:`, text);
            alert('خطأ أثناء تغيير حالة المفضل!');
        }
    } catch (e) {
        console.error(`[CONTROL] Exception updating property #${id}:`, e);
        alert('خطأ أثناء تغيير حالة المفضل!');
    }
}

// ----------- عرض الصورة مكبرة -----------
function openImageModal(src, title = 'عرض الصورة') {
    // إزالة أي نافذة سابقة
    const existingModal = document.getElementById('dynamicImageModal');
    if (existingModal) {
        existingModal.remove();
    }

    // إنشاء النافذة المنبثقة
    const modalHTML = `
        <div class="modal fade" id="dynamicImageModal" tabindex="-1" aria-labelledby="dynamicImageModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="dynamicImageModalLabel">${title}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                    </div>
                    <div class="modal-body text-center">
                        <img src="${src}" class="img-fluid" alt="${title}" style="max-height: 70vh; border-radius: 8px;">
                    </div>
                </div>
            </div>
        </div>
    `;

    // إضافة النافذة إلى الصفحة
    document.body.insertAdjacentHTML('beforeend', modalHTML);

    // عرض النافذة
    const modal = new bootstrap.Modal(document.getElementById('dynamicImageModal'));
    modal.show();

    // إزالة النافذة عند الإغلاق
    document.getElementById('dynamicImageModal').addEventListener('hidden.bs.modal', function () {
        this.remove();
    });
}

function openImgFull(src) {
    openImageModal(src, 'صورة التطبيق');
}

// ----------- نظام التحديث التلقائي -----------
function startPolling() {
    if (pollingInterval) clearInterval(pollingInterval);
    pollingInterval = setInterval(() => {
        renderCurrentTab(true);
    }, 1000); // كل 1 ثانية
    console.log('[CONTROL] Auto-refresh started (every 1 second)');
}

function stopPolling() {
    if (pollingInterval) {
        clearInterval(pollingInterval);
        pollingInterval = null;
        console.log('[CONTROL] Auto-refresh stopped');
    }
}

// ----------- عند التحميل -----------
document.addEventListener('DOMContentLoaded', function() {
    switchTab('restaurants');
    startPolling();
});

// إيقاف التحديث التلقائي عند مغادرة الصفحة
window.addEventListener('beforeunload', function() {
    stopPolling();
});
</script>
@endsection