@extends('layouts.dashboard')

@section('title', 'محادثات العملاء')

@section('content')

{{-- ========== قسم الأنماط (CSS) الخاص بالصفحة (يبقى كما هو) ========== --}}
<style>
    :root {
        --primary-orange: #FC8700;
        --light-gray: #f8f9fa;
        --dark-gray: #343a40;
        --white: #ffffff;
        --shadow-lg: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
    }
    .chat-container { display: flex; height: calc(100vh - 4rem); background: var(--white); border-radius: 20px; box-shadow: var(--shadow-lg); overflow: hidden;}
    .conversations-list { min-width: 320px; max-width: 320px; border-left: 1px solid #dee2e6; display: flex; flex-direction: column; background-color: var(--light-gray);}
    .list-header { padding: 1.25rem; border-bottom: 1px solid #dee2e6;}
    .list-header h4 { margin: 0; color: var(--primary-orange);}
    .list-body { overflow-y: auto; flex-grow: 1;}
    .conversation-item { display: flex; align-items: center; padding: 1rem 1.25rem; cursor: pointer; transition: background-color 0.2s ease; border-bottom: 1px solid #e9ecef;}
    .conversation-item:hover { background-color: #e9ecef;}
    .conversation-item.active { background-color: var(--primary-orange); color: var(--white);}
    .conversation-item.active .conversation-details h6, .conversation-item.active .conversation-details p { color: var(--white);}
    .profile-pic { width: 50px; height: 50px; border-radius: 50%; margin-left: 1rem; object-fit: cover;}
    .conversation-details { flex-grow: 1; overflow: hidden;}
    .conversation-details h6 { margin: 0; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;}
    .conversation-details p { margin: 0; font-size: 0.9rem; color: #6c757d; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;}
    .chat-area { flex-grow: 1; display: flex; flex-direction: column;}
    .chat-header { display: flex; align-items: center; padding: 1rem 1.5rem; background-color: var(--white); border-bottom: 1px solid #e9ecef;}
    #emptyChatView { display: flex; flex-direction: column; justify-content: center; align-items: center; height: 100%; color: #6c757d;}
    #emptyChatView i { font-size: 5rem; color: #e9ecef;}
    .messages-area { flex-grow: 1; overflow-y: auto; padding: 1.5rem; background-color: #f1f2f6;}
    .message-bubble { max-width: 70%; padding: 0.75rem 1.25rem; border-radius: 18px; margin-bottom: 1rem; line-height: 1.5; position: relative;}
    .message-bubble.sent { background-color: var(--white); color: var(--dark-gray); margin-right: auto; border-bottom-right-radius: 4px; box-shadow: 0 1px 2px rgba(0,0,0,0.05);}
    .message-bubble.received { background-color: var(--primary-orange); color: var(--white); margin-left: auto; border-bottom-left-radius: 4px;}
    .chat-footer { padding: 1rem 1.5rem; background-color: var(--white); border-top: 1px solid #e9ecef;}
    #sendMessageForm { display: flex; align-items: center;}
    #messageInput { flex-grow: 1; border: 1px solid #dee2e6; border-radius: 20px; padding: 0.75rem 1.25rem; resize: none; transition: box-shadow 0.2s ease;}
    #messageInput:focus { box-shadow: 0 0 0 0.2rem rgba(252, 135, 0, 0.25); border-color: var(--primary-orange);}
    #sendMessageBtn { min-width: 50px; height: 50px; border-radius: 50%; background-color: var(--primary-orange); color: white; border: none; margin-right: 1rem; font-size: 1.5rem; transition: background-color 0.2s ease;}
    #sendMessageBtn:hover { background-color: #e67600;}
</style>

{{-- ========== قسم HTML الخاص بالصفحة (يبقى كما هو) ========== --}}
<div class="chat-container">
    <div class="conversations-list">
        <div class="list-header">
            <h4>جميع المحادثات</h4>
        </div>
        <div class="list-body" id="conversationsContainer">
            <p class="p-3 text-muted">جاري تحميل المحادثات...</p>
        </div>
    </div>
    <div class="chat-area">
        <div id="chatInterface" class="d-none w-100 h-100 d-flex flex-column">
            <div class="chat-header">
                <img id="chatWithPic" src="" class="profile-pic">
                <h5 id="chatWithName" class="mb-0"></h5>
            </div>
            <div class="messages-area" id="messagesContainer">
                <!-- الرسائل هنا -->
            </div>
            <div class="chat-footer">
                <form id="sendMessageForm">
                    <button type="submit" id="sendMessageBtn" disabled><i class="bi bi-send-fill"></i></button>
                    <textarea id="messageInput" class="form-control" rows="1" placeholder="اكتب رسالتك هنا..." disabled></textarea>
                </form>
            </div>
        </div>
        <div id="emptyChatView" class="d-flex w-100 h-100 justify-content-center align-items-center flex-column">
             <i class="bi bi-chat-left-dots"></i>
             <h4 class="mt-3">اختر محادثة لعرضها</h4>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    // --- [1] Laravel Echo config (كما هو) ---
    try {
        if (typeof Echo !== 'undefined' && typeof Pusher !== 'undefined') {
            const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');
            window.Echo = new Echo({
                broadcaster: 'pusher',
                key: '{{ config('broadcasting.connections.pusher.key') }}',
                cluster: '{{ config('broadcasting.connections.pusher.options.cluster') }}',
                forceTLS: true,
                authEndpoint: '/broadcasting/auth',
                auth: {
                    headers: { 'X-CSRF-TOKEN': csrfToken }
                }
            });
        } else {
            console.error('Echo or Pusher not found.');
            return;
        }
    } catch (e) {
        console.error('Failed to initialize Laravel Echo:', e);
        return;
    }

    // --- [2] Variables ---
    const API_TOKEN = localStorage.getItem('token');
    if (!API_TOKEN) { window.location.href = '/login'; return; }
    const IMAGE_PLACEHOLDER = 'https://via.placeholder.com/50/FC8700/FFFFFF?text=M';
    const IMAGE_BASE_URL = '{{ rtrim(config('app.url'), '/') }}/storage/';
    let activeConversation = null;
    let conversations = [];
    let loggedInAdmin = JSON.parse(localStorage.getItem('user'));

    const conversationsContainer = document.getElementById('conversationsContainer');
    const messagesContainer = document.getElementById('messagesContainer');
    const chatInterface = document.getElementById('chatInterface');
    const emptyChatView = document.getElementById('emptyChatView');
    const chatWithName = document.getElementById('chatWithName');
    const chatWithPic = document.getElementById('chatWithPic');
    const sendMessageForm = document.getElementById('sendMessageForm');
    const messageInput = document.getElementById('messageInput');
    const sendMessageBtn = document.getElementById('sendMessageBtn');

    // --- [3] Polling (التحديث كل ثانية) ---
    let pollingInterval = null;
    let lastMessageId = null;

    function startPollingMessages(conversationId, userId) {
        stopPollingMessages();
        pollingInterval = setInterval(async function() {
            if (!activeConversation || activeConversation.id != conversationId) return; // أمان
            try {
                const response = await fetch(`/api/admin/chats/${userId}`, {
                    headers: { 'Authorization': `Bearer ${API_TOKEN}`, 'Accept': 'application/json' }
                });
                if (!response.ok) return;
                const result = await response.json();
                if (result.status && result.data && result.data.messages) {
                    const messages = result.data.messages;
                    const newLastId = messages[messages.length - 1]?.id ?? null;
                    if (newLastId !== lastMessageId) {
                        renderMessages(messages);
                    }
                }
            } catch (error) {}
        }, 1000);
    }

    function stopPollingMessages() {
        if (pollingInterval) {
            clearInterval(pollingInterval);
            pollingInterval = null;
        }
    }
    window.addEventListener('beforeunload', stopPollingMessages);

    // --- [4] Echo events ---
    let activeChannel = null;
    function listenToConversation(conversationId) {
        if (activeChannel) {
            window.Echo.leave(activeChannel);
        }
        activeChannel = `chat.${conversationId}`;
        window.Echo.private(activeChannel)
            .listen('.new-message', (e) => {
                // إذا كانت الرسالة واردة من المستخدم الآخر وليس من الأدمن الحالي
                if (activeConversation && e.message.sender_id !== loggedInAdmin.id && e.message.conversation_id === activeConversation.id) {
                    appendMessage(e.message, 'sent');
                }
            });
    }

    // --- [5] Rendering ---
    function appendMessage(message, type = 'received') {
        const messageClass = type === 'received' ? 'received' : 'sent';
        const newMessageBubble = `
            <div class="message-bubble ${messageClass}" data-id="${message.id ?? ''}">
                ${message.content.replace(/\n/g, '<br>')}
            </div>`;
        const noMessagesP = messagesContainer.querySelector('p');
        if (noMessagesP) noMessagesP.remove();
        messagesContainer.innerHTML += newMessageBubble;
        scrollToBottom();
        // تحديث آخر id
        const allBubbles = messagesContainer.querySelectorAll('.message-bubble[data-id]');
        if (allBubbles.length > 0) {
            lastMessageId = allBubbles[allBubbles.length - 1].dataset.id;
        }
    }

    async function fetchConversations() {
        try {
            const response = await fetch('/api/admin/chats', {
                headers: { 'Authorization': `Bearer ${API_TOKEN}`, 'Accept': 'application/json' }
            });
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            const result = await response.json();
            if (result.status && result.data.data) {
                conversations = result.data.data;
                renderConversations();
            } else {
                conversationsContainer.innerHTML = '<p class="p-3 text-danger">فشل في تحميل المحادثات.</p>';
            }
        } catch (error) {
            conversationsContainer.innerHTML = `<p class="p-3 text-danger">خطأ فني. تحقق من الـ Console.</p>`;
        }
    }

    function renderConversations() {
        if (conversations.length === 0) {
            conversationsContainer.innerHTML = '<p class="p-3 text-muted">لا توجد محادثات حتى الآن.</p>';
            return;
        }
        conversationsContainer.innerHTML = conversations.map(convo => `
            <div class="conversation-item" data-id="${convo.id}">
                <img width="75px" src="https://avatar.iran.liara.run/public/8">
                <div class="conversation-details"><h6>${convo.user.name}</h6><p>${convo.messages_count} رسالة</p></div>
            </div>`).join('');
    }

    function renderMessages(messages) {
        if (!messages || messages.length === 0) {
            messagesContainer.innerHTML = '<p class="text-center text-muted p-5">لا توجد رسائل في هذه المحادثة بعد.</p>';
            lastMessageId = null;
            return;
        }
        messagesContainer.innerHTML = messages.map(msg => {
            const isSentByAdmin = msg.sender_id === loggedInAdmin.id;
            return `<div class="message-bubble ${isSentByAdmin ? 'received' : 'sent'}" data-id="${msg.id}">${msg.content.replace(/\n/g, '<br>')}</div>`;
        }).join('');
        lastMessageId = messages[messages.length - 1]?.id ?? null;
        scrollToBottom();
    }

    function scrollToBottom() { messagesContainer.scrollTop = messagesContainer.scrollHeight; }

    // --- [6] Events (فتح المحادثة) ---
    conversationsContainer.addEventListener('click', async function(e) {
        const item = e.target.closest('.conversation-item');
        if (!item) return;
        stopPollingMessages(); // أمان، أوقف المؤقت قبل فتح الجديد
        const conversationId = item.dataset.id;
        activeConversation = conversations.find(c => c.id == conversationId);
        if (!activeConversation) { return; }

        messageInput.disabled = false;
        sendMessageBtn.disabled = false;
        document.querySelectorAll('.conversation-item').forEach(el => el.classList.remove('active'));
        item.classList.add('active');
        chatInterface.classList.remove('d-none');
        chatInterface.classList.add('d-flex');
        emptyChatView.style.display = 'none';

        const user = activeConversation.user;
        chatWithName.textContent = user.name;
        chatWithPic.src = user.profile_image ? IMAGE_BASE_URL + user.profile_image : IMAGE_PLACEHOLDER;

        listenToConversation(activeConversation.id);

        messagesContainer.innerHTML = '<p class="text-center p-5 text-muted">جاري تحميل الرسائل...</p>';
        try {
            const response = await fetch(`/api/admin/chats/${user.id}`, { headers: { 'Authorization': `Bearer ${API_TOKEN}`, 'Accept': 'application/json' } });
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            const result = await response.json();
            if (result.status && result.data) {
                renderMessages(result.data.messages);
                startPollingMessages(activeConversation.id, activeConversation.user.id);
            }
        } catch (error) {
            messagesContainer.innerHTML = '<p class="text-center p-5 text-danger">فشل في تحميل الرسائل.</p>';
        }
    });

    // --- [7] إرسال رسالة ---
    sendMessageForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const content = messageInput.value.trim();
        if (!content || !activeConversation) return;

        appendMessage({ content: content, sender_id: loggedInAdmin.id }, 'received');
        const originalMessage = messageInput.value;
        messageInput.value = '';
        messageInput.style.height = 'auto';

        try {
            const response = await fetch(`/api/admin/chats`, { 
                method: 'POST',
                headers: { 'Authorization': `Bearer ${API_TOKEN}`, 'Content-Type': 'application/json', 'Accept': 'application/json' },
                body: JSON.stringify({ content: content, user_id: activeConversation.user.id })
            });
            if (!response.ok) { messageInput.value = originalMessage; }
        } catch (error) {
            messageInput.value = originalMessage;
            alert('حدث خطأ فني أثناء الإرسال!');
        }
    });

    // --- [8] بداية التطبيق ---
    fetchConversations();
});
</script>
@endsection
