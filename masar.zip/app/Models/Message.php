<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    use HasFactory;

    protected $fillable = [
        'conversation_id',
        'sender_id',
        'content', // تم تغيير الاسم ليكون أكثر شيوعاً
        'read_at', // تم تغيير النوع ليحفظ تاريخ القراءة
    ];

    /**
     * لجعل حقل `read_at` من نوع تاريخ
     */
    protected $casts = [
        'read_at' => 'datetime',
    ];

    /**
     * العلاقة لجلب المحادثة التي تنتمي إليها هذه الرسالة
     */
    public function conversation()
    {
        return $this->belongsTo(Conversation::class);
    }

    /**
     * العلاقة لجلب مرسل الرسالة (سواء كان المستخدم أو المشرف)
     */
    public function sender()
    {
        return $this->belongsTo(User::class, 'sender_id');
    }
}