<?php

namespace App\Http\Controllers;

use App\Models\Message;
use App\Models\Conversation;
use Illuminate\Http\Request;

class MessageController extends Controller
{
    // جلب رسائل محادثة
    public function index($conversation_id)
    {
        $messages = Message::where('conversation_id', $conversation_id)
            ->orderBy('created_at')
            ->get();

        return response()->json([
            'status' => true,
            'messages' => $messages
        ]);
    }

    // إرسال رسالة جديدة
    public function store(Request $request)
    {
        $request->validate([
            'conversation_id' => 'required|exists:conversations,id',
            'message' => 'required|string',
        ]);

        $user = auth()->user();
        $conversation = Conversation::findOrFail($request->conversation_id);

        // حدد المرسل والمستقبل
        $sender_id = $user->id;
        $receiver_id = ($conversation->user1_id == $user->id) ? $conversation->user2_id : $conversation->user1_id;

        $msg = Message::create([
            'conversation_id' => $conversation->id,
            'sender_id' => $sender_id,
            'receiver_id' => $receiver_id,
            'message' => $request->message,
        ]);

        return response()->json([
            'status' => true,
            'message' => $msg
        ], 201);
    }

    // حذف رسالة (Soft delete)
    public function destroy($id)
    {
        $user = auth()->user();
        $msg = Message::findOrFail($id);

        // فقط المرسل أو الأدمن يقدر يحذف
        if ($msg->sender_id != $user->id && $user->user_type !== 'admin') {
            return response()->json(['status' => false, 'message' => 'غير مسموح'], 403);
        }

        $msg->update(['is_deleted' => true]);
        return response()->json(['status' => true, 'message' => 'تم حذف الرسالة']);
    }
}
