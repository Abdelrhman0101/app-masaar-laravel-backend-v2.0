<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\MenuItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    /**
     * [خاص بالعميل] إنشاء طلب جديد.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([ 'restaurant_id' => 'required|exists:restaurant_details,id', 'items' => 'required|array|min:1', 'items.*.menu_item_id' => 'required|exists:menu_items,id', 'items.*.quantity' => 'required|integer|min:1', 'note' => 'nullable|string', ]);
        $user = auth()->user(); $subtotal = 0; $orderItemsData = [];
        foreach ($validatedData['items'] as $item) {
            $menuItem = MenuItem::find($item['menu_item_id']); $unitPrice = $menuItem->price; $total = $unitPrice * $item['quantity']; $subtotal += $total;
            $orderItemsData[] = [ 'menu_item_id' => $menuItem->id, 'title' => $menuItem->title, 'quantity' => $item['quantity'], 'unit_price' => $unitPrice, 'total_price' => $total, 'image' => $menuItem->image, ];
        }
        $deliveryFee = 0; $vat = 0; $total = $subtotal + $deliveryFee + $vat;
        $orderNumber = 'ORD-' . time() . rand(100, 999);
        $order = Order::create([ 'user_id' => $user->id, 'restaurant_id' => $validatedData['restaurant_id'], 'status' => 'pending', 'order_number' => $orderNumber, 'subtotal' => $subtotal, 'delivery_fee' => $deliveryFee, 'vat' => $vat, 'total_price' => $total, 'note' => $validatedData['note'] ?? null, ]);
        $order->items()->createMany($orderItemsData);
        return response()->json([ 'status' => true, 'message' => 'تم إرسال الطلب بنجاح. في انتظار موافقة الإدارة.', 'order' => $order->load('items'), ], 201);
    }

    /**
     * [خاص بالمشرف] عرض كل الطلبات في النظام.
     */
    public function index(Request $request)
    {
        $query = Order::with(['user:id,name', 'restaurant:id,restaurant_name', 'items']);
        if ($request->has('status')) { $query->where('status', $request->status); }
        return response()->json([ 'status' => true, 'orders' => $query->latest()->get(), ]);
    }

    /**
     * [عام] عرض تفاصيل طلب معين.
     */
    public function show(Order $order)
    {
        $order->load(['user', 'restaurant', 'items.menuItem']);
        return response()->json(['status' => true, 'order' => $order, ]);
    }
    
    /**
     * [خاص بالمشرف] الموافقة على طلب.
     */
    public function approve(Order $order)
    {
        if ($order->status !== 'pending') { return response()->json(['status' => false, 'message' => 'يمكن فقط الموافقة على الطلبات التي في حالة الانتظار.'], 409); }
        $order->update(['status' => 'accepted_by_admin']);
        return response()->json(['status' => true, 'message' => 'تمت الموافقة على الطلب بنجاح.', 'order' => $order]);
    }

    /**
     * [خاص بالمشرف] رفض طلب.
     */
    public function reject(Order $order)
    {
        if ($order->status !== 'pending') { return response()->json(['status' => false, 'message' => 'يمكن فقط رفض الطلبات التي في حالة الانتظار.'], 409); }
        $order->update(['status' => 'rejected_by_admin']);
        return response()->json(['status' => true, 'message' => 'تم رفض الطلب.', 'order' => $order]);
    }


    // ===========================================
    //  !!     الدوال الخاصة بالمطعم فقط     !!
    // ===========================================
    
    /**
     * [خاص بالمطعم] عرض قائمة الطلبات الخاصة بالمطعم الحالي.
     * GET /api/restaurant/orders
     */
    public function restaurantOrders(Request $request)
    {
        $restaurantUser = Auth::user();

        // **التحقق من الصلاحية**
        if ($restaurantUser->user_type !== 'restaurant' || !$restaurantUser->restaurantDetail) {
            return response()->json(['status' => false, 'message' => 'هذا الحساب غير مصرح له بعرض الطلبات.'], 403);
        }
        
        $restaurantId = $restaurantUser->restaurantDetail->id;

        $query = Order::with(['user:id,name,phone', 'items'])
                      ->where('restaurant_id', $restaurantId);

        if ($request->has('status')) {
            $query->where('status', $request->status);
        }
        
        $orders = $query->latest()->get();

        return response()->json([
            'status' => true,
            'orders' => $orders,
        ]);
    }

    /**
     * [خاص بالمطعم] تحويل الطلب إلى "قيد التنفيذ".
     */
    public function process(Order $order)
    {
        $restaurantUser = Auth::user();

        if ($restaurantUser->user_type !== 'restaurant' || $restaurantUser->restaurantDetail?->id !== $order->restaurant_id) {
            return response()->json(['status' => false, 'message' => 'غير مصرح لك بتنفيذ هذا الإجراء.'], 403);
        }
        
        if ($order->status !== 'accepted_by_admin') {
            return response()->json(['status' => false, 'message' => 'يمكن فقط تنفيذ الطلبات التي تمت الموافقة عليها من الإدارة.'], 409);
        }

        $order->update(['status' => 'processing']);

        return response()->json(['status' => true, 'message' => 'تم بدء تنفيذ الطلب.', 'order' => $order]);
    }

    /**
     * [خاص بالمطعم] إنهاء الطلب.
     */
    public function complete(Order $order)
    {
        $restaurantUser = Auth::user();
        
        if ($restaurantUser->user_type !== 'restaurant' || $restaurantUser->restaurantDetail?->id !== $order->restaurant_id) {
            return response()->json(['status' => false, 'message' => 'غير مصرح لك بتنفيذ هذا الإجراء.'], 403);
        }

        if ($order->status !== 'processing') {
            return response()->json(['status' => false, 'message' => 'يمكن فقط إنهاء الطلبات التي هي قيد التنفيذ.'], 409);
        }

        $order->update(['status' => 'completed']);
        
        return response()->json(['status' => true, 'message' => 'تم إنهاء الطلب بنجاح.', 'order' => $order]);
    }
}