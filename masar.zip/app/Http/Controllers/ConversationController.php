<?php

namespace App\Http\Controllers;

use App\Models\Conversation;
use App\Models\User;
use Illuminate\Http\Request;

class ConversationController extends Controller
{
    // قائمة المحادثات الخاصة بالمستخدم الحالي (أو للإدارة كل المحادثات)
    public function index(Request $request)
    {
        $user = auth()->user();

        // لو هو أدمن: استعرض كل المحادثات
        if ($user->user_type === 'admin') {
            $conversations = Conversation::with(['user1', 'user2'])
                ->latest()->get();
        } else {
            // باقي المستخدمين: استعرض محادثاته فقط
            $conversations = Conversation::with(['user1', 'user2'])
                ->where('user1_id', $user->id)
                ->orWhere('user2_id', $user->id)
                ->latest()->get();
        }

        return response()->json([
            'status' => true,
            'conversations' => $conversations
        ]);
    }

    // بدء محادثة جديدة (أو إرجاع الموجودة)
    public function startOrGet(Request $request)
{
    $user = auth()->user();

    // لو الأدمن عايز يبدأ محادثة مع مستخدم معين
    if ($user->user_type === 'admin' && $request->filled('user_id')) {
        $targetUserId = $request->input('user_id');
        $adminId = $user->id;
    } else {
        // أي مستخدم آخر يفتح محادثة مع الأدمن تلقائيًا
        $targetUserId = $user->id;
        $adminId = User::where('user_type', 'admin')->value('id');
        if (!$adminId) {
            return response()->json(['status' => false, 'message' => 'لا يوجد مدير في النظام!'], 422);
        }
    }

    // البحث أو إنشاء المحادثة
    $conversation = Conversation::firstOrCreate([
        'user1_id' => $targetUserId,
        'user2_id' => $adminId,
    ], [
        'started_by' => $user->id,
    ]);

    return response()->json([
        'status' => true,
        'conversations' => $conversation
    ]);
}

}
