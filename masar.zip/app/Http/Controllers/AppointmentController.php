<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\Property;
use Illuminate\Http\Request;

class AppointmentController extends Controller
{
    // إضافة موعد جديد (يقدر أي يوزر يعملها)
    public function store(Request $request)
    {
        $validated = $request->validate([
            'property_id' => 'required|exists:properties,id',
            'date'        => 'required|date_format:Y-m-d H:i',
            'note'        => 'nullable|string',
        ]);

        $property = Property::findOrFail($validated['property_id']);

        // تحقق من ربط العقار بمقدم خدمة
        if (!$property->user_id) {
            return response()->json([
                'status'  => false,
                'message' => 'لا يمكن حجز موعد لهذا العقار لأنه غير مرتبط بمقدم خدمة.',
            ], 422);
        }

        $appointment = Appointment::create([
            'property_id'         => $property->id,
            'customer_id'         => $request->user()->id,
            'provider_id'         => $property->user_id,
            'appointment_datetime'=> $validated['date'],
            'note'                => $validated['note'] ?? null,
            'status'              => 'pending',
            'last_action_by'      => 'customer',
            'updated_by'          => $request->user()->id,
        ]);

        return response()->json([
            'status'      => true,
            'message'     => 'تم إرسال طلب المعاينة للإدارة.',
            'appointment' => $appointment
        ], 201);
    }

    // عرض كل المواعيد (للإدارة فقط أو للتجربة)
    public function index()
    {
        $appointments = Appointment::with(['property', 'customer', 'provider'])->get();
        return response()->json([
            'status'      => true,
            'appointments'=> $appointments
        ]);
    }

    // تعديل حالة الموعد (موافقة/رفض من الأدمن أو مقدم الخدمة)
    public function updateStatus(Request $request, $id)
    {
        $appointment = Appointment::findOrFail($id);

        $validated = $request->validate([
            'status'        => 'required|in:pending,admin_approved,provider_approved,provider_requested_change,rejected,completed',
            'admin_note'    => 'nullable|string',
            'provider_note' => 'nullable|string',
        ]);

        // تحديد من قام بالتحديث (مثلا حسب صلاحية المستخدم)
        $who = 'admin';
        if ($request->user()->user_type === 'real_estate_office' || $request->user()->user_type === 'real_estate_individual') {
            $who = 'provider';
        } elseif ($request->user()->user_type === 'normal') {
            $who = 'customer';
        }

        $appointment->update([
            ...$validated,
            'last_action_by' => $who,
            'updated_by'     => $request->user()->id,
        ]);

        return response()->json([
            'status'      => true,
            'message'     => 'تم تحديث حالة الموعد بنجاح',
            'appointment' => $appointment
        ]);
    }

    // عرض المواعيد الخاصة بالمستخدم الحالي (كعميل)
    public function myAppointments(Request $request)
    {
        $appointments = Appointment::with(['property'])
            ->where('customer_id', $request->user()->id)
            ->get();

        return response()->json([
            'status'      => true,
            'appointments'=> $appointments
        ]);
    }

    // عرض المواعيد الخاصة بمقدم الخدمة الحالي (كمكتب/فرد)
    public function providerAppointments(Request $request)
    {
        $appointments = Appointment::with(['property', 'customer'])
            ->where('provider_id', $request->user()->id)
            ->get();

        return response()->json([
            'status'      => true,
            'appointments'=> $appointments
        ]);
    }
}
