<?php

namespace App\Http\Controllers\Api;

use App\Events\MessageSent; // <-- **الخطوة 1: إضافة الـ use statement**
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserChatController extends Controller
{
    /**
     * جلب محادثة المستخدم الحالية مع الإدارة، وإنشاؤها إذا لم تكن موجودة.
     * GET /api/chat
     */
    public function show()
    {
        $user = Auth::user();

        // باستخدام علاقة hasOne، نصل للمحادثة مباشرة.
        // firstOrCreate تضمن إنشاء المحادثة بـ user_id الصحيح إذا كانت غير موجودة.
        $conversation = $user->conversation()->firstOrCreate([]);
        
        // جلب المحادثة مع كل الرسائل مرتبة
        // سيتم تحميل الرسائل مع المحادثة بفضل 'with' في الموديل أو هنا
        $conversation->load('messages.sender:id,name');

        return response()->json([
            'status' => true,
            'data' => $conversation
        ]);
    }

    /**
     * إرسال رسالة من المستخدم إلى الإدارة.
     * POST /api/chat
     */
    public function store(Request $request)
    {
        $request->validate(['content' => 'required|string|max:5000']);

        $user = Auth::user();

        // نجد محادثة المستخدم (أو ننشئها)
        $conversation = $user->conversation()->firstOrCreate([]);
        
        // الآن ننشئ الرسالة. لاحظ كيف أن المنطق بسيط ومباشر.
        $message = $conversation->messages()->create([
            'sender_id' => $user->id,
            'content' => $request->content,
        ]);
        
        $conversation->touch(); // تحديث الطابع الزمني للمحادثة
        
        // **الخطوة 2: إضافة سطر إطلاق الحدث**
        // سيتم بث الرسالة الجديدة لكل من يستمع على هذه القناة
        // (وهم المشرفون في لوحة التحكم)
        broadcast(new MessageSent($message))->toOthers();

        return response()->json([
            'status' => true,
            'message' => 'Message sent successfully.',
            'data' => $message
        ], 201);
    }
}