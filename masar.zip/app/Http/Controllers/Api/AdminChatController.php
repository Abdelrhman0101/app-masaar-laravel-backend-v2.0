<?php

namespace App\Http\Controllers\Api;

use App\Events\MessageSent;
use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\User; // ** تأكد من وجود هذا **
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class AdminChatController extends Controller
{
    /**
     * عرض قائمة بكل المحادثات الموجودة في النظام للمشرف.
     * GET /api/admin/chats
     */
    public function index()
    {
        try {
            $conversations = Conversation::with(['user:id,name,profile_image'])
                ->withCount('messages')
                ->latest('updated_at')
                ->paginate(30);

            return response()->json([
                'status' => true,
                'data' => $conversations
            ]);

        } catch (\Exception $e) {
            Log::error('Chat API Error in AdminChatController@index: ' . $e->getMessage());
            return response()->json([
                'status' => false,
                'message' => 'An error occurred while fetching conversations.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * عرض محادثة معينة بكل رسائلها بناءً على ID المستخدم.
     * GET /api/admin/chats/{user}
     * (النسخة النهائية والمصححة)
     */
    public function show($userId) // **تم التغيير:** لم نعد نستخدم Route Model Binding هنا
    {
        // **الخطوة 1: البحث عن المستخدم يدويًا**
        $user = User::find($userId);

        // **الخطوة 2: التحقق مما إذا كان المستخدم موجودًا**
        if (!$user) {
            return response()->json(['status' => false, 'message' => 'User not found.'], 404);
        }

        // --- باقي المنطق يبقى كما هو ---
        
        if ($user->user_type === 'admin') {
            return response()->json(['status' => false, 'message' => 'Cannot start a chat with another admin.'], 422);
        }

        $conversation = $user->conversation()->with('messages')->first();

        if (!$conversation) {
             return response()->json([
                'status' => true, 
                'data' => [
                    'id' => null,
                    'user_id' => $user->id,
                    'user' => $user,
                    'messages' => []
                ]
            ]);
        }
        
        return response()->json(['status' => true, 'data' => $conversation]);
    }

    /**
     * إرسال رسالة من المشرف إلى مستخدم معين.
     * POST /api/admin/chats
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'user_id' => 'required|exists:users,id',
            'content' => 'required|string|max:5000',
        ]);

        $admin = Auth::user();
        $user = User::find($validated['user_id']);

        if ($user->user_type === 'admin') {
            return response()->json(['status' => false, 'message' => 'Cannot send a message to another admin.'], 422);
        }

        $conversation = $user->conversation()->firstOrCreate([]);
        
        $message = $conversation->messages()->create([
            'sender_id' => $admin->id,
            'content' => $validated['content'],
        ]);
        
        $conversation->touch();
        
        broadcast(new MessageSent($message))->toOthers();

        return response()->json([
            'status' => true,
            'message' => 'Message sent successfully.',
            'data' => $message
        ], 201);
    }
}