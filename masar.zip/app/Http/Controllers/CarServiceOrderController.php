<?php

namespace App\Http\Controllers;

use App\Models\CarServiceOrder;
use App\Models\OrderOffer;
use App\Models\OrderStatusHistory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Models\User;

class CarServiceOrderController extends Controller
{
    // 1. إضافة طلب جديد (من العميل)
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'car_rental_id' => 'required|exists:car_rentals,id',
            'order_type'    => 'required|in:rent,ride',
            'car_category'  => 'nullable|string|max:255',
            'payment_method'=> 'required|in:cash,bank_transfer',
            'requested_price'=> 'nullable|numeric',
            'from_location' => 'required|string|max:255',
            'to_location'   => 'required|string|max:255',
            'delivery_time' => 'nullable|date',
            'requested_date'=> 'nullable|date',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation errors',
                'errors' => $validator->errors(),
            ], 422);
        }

        $order = CarServiceOrder::create([
            'client_id'      => Auth::id(),
            'car_rental_id'  => $request->car_rental_id,
            'order_type'     => $request->order_type,
            'car_category'   => $request->car_category,
            'payment_method' => $request->payment_method,
            'status'         => 'pending_admin',
            'requested_price'=> $request->requested_price,
            'from_location'  => $request->from_location,
            'to_location'    => $request->to_location,
            'delivery_time'  => $request->delivery_time,
            'requested_date' => $request->requested_date,
        ]);

        // سجل أول حالة
        OrderStatusHistory::create([
            'order_id'   => $order->id,
            'status'     => 'pending_admin',
            'changed_by' => Auth::id(),
            'note'       => 'تم إنشاء الطلب ويحتاج مراجعة الإدارة',
        ]);

        return response()->json([
            'status' => true,
            'message' => 'تم إرسال الطلب بنجاح، في انتظار موافقة الإدارة',
            'order' => $order,
        ]);
    }

    // 2. عرض كل الطلبات (فلترة)
    public function index(Request $request)
    {
        $query = CarServiceOrder::query();

        // فلترة حسب نوع المستخدم (عميل أو مقدم خدمة أو إدارة)
        if ($request->has('client_id')) {
            $query->where('client_id', $request->client_id);
        }
        if ($request->has('provider_id')) {
            $query->where('provider_id', $request->provider_id);
        }
        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        $orders = $query->with(['client', 'provider', 'carRental', 'offers', 'statusHistories'])
                        ->orderBy('created_at', 'desc')
                        ->get();

        return response()->json([
            'status' => true,
            'orders' => $orders,
        ]);
    }

    // 3. عرض تفاصيل طلب
    public function show($id)
    {
        $order = CarServiceOrder::with(['client', 'provider', 'carRental', 'offers', 'statusHistories'])->findOrFail($id);

        return response()->json([
            'status' => true,
            'order' => $order,
        ]);
    }

    // 4. موافقة الإدارة على الطلب (يغير الحالة إلى pending_provider)
    public function approveByAdmin($id)
    {
        $order = CarServiceOrder::findOrFail($id);
        if ($order->status !== 'pending_admin') {
            return response()->json(['status' => false, 'message' => 'لا يمكن اعتماد هذا الطلب الآن!'], 400);
        }

        $order->status = 'pending_provider';
        $order->save();

        // سجل التغيير
        OrderStatusHistory::create([
            'order_id'   => $order->id,
            'status'     => 'pending_provider',
            'changed_by' => Auth::id(),
            'note'       => 'تم اعتماد الطلب من الإدارة.',
        ]);

        // هنا ممكن تضيف كود إرسال إشعار للـ providers

        return response()->json(['status' => true, 'message' => 'تم اعتماد الطلب وإرساله لمقدمي الخدمة']);
    }

    // 5. رفض الطلب (الإدارة)
    public function rejectByAdmin($id)
    {
        $order = CarServiceOrder::findOrFail($id);
        if ($order->status !== 'pending_admin') {
            return response()->json(['status' => false, 'message' => 'لا يمكن رفض هذا الطلب الآن!'], 400);
        }

        $order->status = 'rejected';
        $order->rejected_at = now();
        $order->save();

        // سجل التغيير
        OrderStatusHistory::create([
            'order_id'   => $order->id,
            'status'     => 'rejected',
            'changed_by' => Auth::id(),
            'note'       => 'تم رفض الطلب من الإدارة.',
        ]);

        return response()->json(['status' => true, 'message' => 'تم رفض الطلب!']);
    }

    // باقي الأكواد (تقديم عرض، قبول/رفض، تغيير حالة الطلب…) نضيفها في الخطوات الجاية

    public function offer(Request $request, $orderId)
{
    $validator = Validator::make($request->all(), [
        'offered_by' => 'required|in:provider,client',
        'price'      => 'required|numeric',
        'offer_note' => 'nullable|string|max:500',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => false,
            'message' => 'Validation errors',
            'errors' => $validator->errors(),
        ], 422);
    }

    $order = CarServiceOrder::findOrFail($orderId);

    // لا يمكن التفاوض إلا على طلب تحت حالات معينة
    if (!in_array($order->status, ['pending_provider', 'negotiation'])) {
        return response()->json([
            'status' => false,
            'message' => 'لا يمكن التفاوض على هذا الطلب حالياً',
        ], 400);
    }

    // أضف العرض
    $offer = OrderOffer::create([
        'order_id'   => $orderId,
        'offered_by' => $request->offered_by,
        'price'      => $request->price,
        'offer_note' => $request->offer_note,
    ]);

    // حدث حالة الطلب
    $order->status = 'negotiation';
    $order->save();

    // سجل التغيير
    OrderStatusHistory::create([
        'order_id'   => $order->id,
        'status'     => 'negotiation',
        'changed_by' => Auth::id(),
        'note'       => 'تقديم عرض جديد',
    ]);

    return response()->json([
        'status' => true,
        'message' => 'تم تقديم العرض بنجاح',
        'offer' => $offer,
    ]);
}

// 7. قبول العرض (نهائي من الطرف الآخر)
public function acceptOffer(Request $request, $orderId, $offerId)
{
    $order = CarServiceOrder::findOrFail($orderId);
    $offer = OrderOffer::where('order_id', $orderId)->findOrFail($offerId);

    // نقبل العرض، ونحدث الطلب
    $order->agreed_price = $offer->price;
    $order->status = 'accepted';
    $order->provider_id = $order->provider_id ?? Auth::id(); // في أول قبول فقط
    $order->accepted_at = now();
    $order->save();

    // سجل التغيير
    OrderStatusHistory::create([
        'order_id'   => $order->id,
        'status'     => 'accepted',
        'changed_by' => Auth::id(),
        'note'       => 'تم قبول العرض والاتفاق على السعر النهائي',
    ]);

    // هنا ممكن ترسل إشعار للطرفين

    return response()->json([
        'status' => true,
        'message' => 'تم قبول العرض، والطلب جاهز للتنفيذ',
        'order' => $order,
    ]);
}

}
